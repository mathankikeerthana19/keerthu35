
<?php
include('db.php');

$booking_id = isset($_POST['booking_id']) ? (int)$_POST['booking_id'] : 0;

if ($booking_id > 0) {
    $query = "SELECT * FROM bookings WHERE id = $booking_id";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $booking = mysqli_fetch_assoc($result);
    } else {
        echo "<h3>No booking found.</h3>";
        exit;
    }
} else {
    echo "<h3>Invalid booking ID.</h3>";
    exit;
}

$transaction_id = "TXN" . rand(100000, 999999);
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Success</title>
    <style>
        body {
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .success-card {
            background-color: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            width: 700px;
        }

        .success-card h2 {
            color: #2e7d32;
            text-align: center;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 18px;
            font-weight: bold;
            color: #2e7d32;
            margin-top: 20px;
            margin-bottom: 10px;
        }

        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px 30px;
            color: #333;
            font-size: 16px;
        }

        .details-grid div {
            padding: 5px 0;
        }

        .details-grid b {
            color: #000;
        }

        .print-btn {
            background-color: #4CAF50;
            color: #fff;
            padding: 12px 30px;
            border-radius: 25px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            display: block;
            margin: 30px auto 0;
        }

        .print-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="success">✔ Payment Successful!</div><br>
    <p>Thank you, <b><?php echo htmlspecialchars($booking['name']); ?></b>, for booking your dance class.</p>

    <div class="details">
        <p><b>Class Name:</b> <?php echo htmlspecialchars($booking['dance_class']); ?></p>
        <p><b>Timing:</b> <?php echo htmlspecialchars($booking['timing']); ?></p>
        <p><b>Fees Paid:</b> ₹<?php echo htmlspecialchars($booking['fees']); ?></p>

        <h3 style="color:blue;">Student Details</h3>
        <p><b>Name:</b> <?php echo htmlspecialchars($booking['name']); ?></p>
        <p><b>Contact:</b> <?php echo htmlspecialchars($booking['phone']); ?></p>
        <p><b>Email:</b> <?php echo htmlspecialchars($booking['email']); ?></p>

        <h3 style="color:blue;">Booking Details</h3>
        <p><b>Booking ID:</b> <?php echo $booking['id']; ?></p>
        <p><b>Transaction ID:</b> <?php echo $transaction_id; ?></p>
        <p><b>Payment Method:</b> UPI</p>
    </div>

    <br>
    <a class="print-btn" href="#" onclick="window.print()">Print Receipt</a>
</body>
</html>
