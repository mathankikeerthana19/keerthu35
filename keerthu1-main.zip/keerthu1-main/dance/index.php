<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dance Class Booking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color:  rgba(104, 90, 230, 0.49); 
            color: black;
            text-align: center;
            padding: 20px 0;
        }

        nav a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
        }

        nav a:hover {
            text-decoration: underline;
        }

        .hero-section {
            background-image: url('dan2.jpeg');
            background-size: cover; 
            background-position: center center; 
            color:  rgba(104, 90, 230, 0.49);
            width: 100%;
            height: 60vh; 
            object-fit: cover;
            display: flex;
            justify-content: center; 
            align-items: flex-end;
            position: relative; 
        }

        .hero-section h2 {
            font-size: 48px;
            font-weight: bold;
            text-align: center;
            text-shadow: 2px 2px 5px  rgba(104, 90, 230, 0.49); 
            margin: 0;
            position: absolute; 
            bottom: 20px; 
            width: 100%; 
        }

        .main-content {
            padding: 20px;
            text-align: center;
        }

        .main-content h2 {
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
        }

        .main-content p {
            font-size: 18px;
            color: #555;
            margin-bottom: 20px;
        }

        .main-content a {
            color: #007bff;
            text-decoration: none;
        }

        .main-content a:hover {
            text-decoration: underline;
        }

        footer {
            background-color:  rgba(104, 90, 230, 0.49); 
            color: black
            
            ;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
        }
    </style>
</head>
<body>

    <header>
        <h1>Welcome to Our Dance Class Booking System</h1>
        <nav>
            <a href="index.php">Home</a> 
            <a href="about.php">About</a> 
            <a href="classes.php">Classes</a> 
            <a href="registration.php">Booking</a> 
            <a href="admin_login.php">Admin</a> 
            
            <a href="feedback.php">Feedback</a>
            <a href="certificate.php">Certificate</a>
        </nav>
    </header>

    
    <section class="hero-section">
        <h2>The Art of Movement</h2>
    </section>

    <div class="main-content">
        <h2 class="intro-text">Get Moving with Our Dance Classes!</h2>
        <p>Whether you're looking to learn the latest dance trends or improve your skills, we have a class for you! Join our passionate instructors and become part of the dance community.</p>

        <p><strong>Choose your favorite style and book a class today!</strong></p>

        <p><a href="classes.php">Browse Classes</a> and find the perfect fit for you!</p>
    </div>

    <footer>
        <p>&copy; 2025 Dance Class Booking System. All rights reserved.</p>
    </footer>

</body>
</html>
