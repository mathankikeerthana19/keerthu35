<?php
session_start();
include('db.php');

if (!isset($_SESSION['booking_id'])) {
    echo "No booking found!";
    exit();
}

$booking_id = $_SESSION['booking_id'];
$query = "SELECT * FROM bookings WHERE id = $booking_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "Booking not found!";
    exit();
}

$booking = mysqli_fetch_assoc($result);
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .payment-container {
            background-color: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        .details {
            text-align: left;
            margin-bottom: 20px;
            line-height: 1.7;
        }
        .details b {
            color: #555;
        }
        input[type="text"] {
            width: 95%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 12px 20px;
            background-color: #28a745;
            border: none;
            color: #fff;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<div class="payment-container">
    <h2>Payment Page</h2>
    <div class="details">
        <b>Booking ID:</b> <?php echo $booking['id']; ?><br>
        <b>Name:</b> <?php echo $booking['name']; ?><br>
        <b>Email:</b> <?php echo $booking['email']; ?><br>
        <b>Phone:</b> <?php echo $booking['phone']; ?><br>
        <b>Age:</b> <?php echo $booking['age']; ?><br>
        <b>Dance Class:</b> <?php echo $booking['dance_class']; ?><br>
        <b>Experience:</b> <?php echo $booking['experience']; ?><br>
        <b>Class Fees:</b> ₹<?php echo $booking['fees']; ?><br>
        <b>Class Timing:</b> <?php echo $booking['timing']; ?><br>
    </div>

    <form action="payment_success.php" method="POST">
        <label for="upi">Enter UPI ID</label><br>
        <input type="text" id="upi" name="upi" placeholder="example@upi" required><br>
        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
        <button type="submit">Proceed to Pay</button>
    </form>
</div>

</body>
</html>
