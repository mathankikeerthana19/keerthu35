<?php
session_start();


$error_message = "";
$success_message = ""; 


$servername = "localhost";  
$username = "root";         
$password = "";             
$dbname = "dance_booking";  

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_SESSION['user_id'])) {
    header("Location: booking.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $username = trim($_POST['username']);  
    $password = $_POST['password'];


    $sql = "SELECT * FROM login WHERE username=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);  
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
      
        $row = $result->fetch_assoc();
   
        if (password_verify($password, $row['password'])) {

            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];


            $success_message = "Login successful! Redirecting to booking page...";
            header("refresh:2;url=booking.php");
            exit();
        } else {
      
            $error_message = "Invalid password.";
        }
    } else {
      
        $error_message = "No user found with this username.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
    <style>
        body {
            background-image: url('purple1.jpeg');
            background-size: cover;
            background-position: center;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.9); 
            padding: 40px;
            border-radius: 8px;
            width: 300px; 
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
        }

        label {
            font-size: 14px;
            margin-bottom: 5px;
            display: block;
            text-align: left;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box; 
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: rgb(182, 160, 233);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            box-sizing: border-box;
        }

        button:hover {
            background-color: rgb(205, 191, 224);
        }

        .error-message, .success-message {
            margin-top: 10px;
            font-size: 14px;
            color: white;
            padding: 10px;
            border-radius: 5px;
        }

        .error-message {
            background-color: #ff4d4d;
        }

        .success-message {
            background-color: #4CAF50; 
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Login Form</h2>
        <form method="POST" action="booking.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        
            <button type="submit">Login</button>
    
        </form>

        <?php if ($error_message): ?>
            <div class="error-message">
                <?php echo $error_message; ?>
            </div>
        <?php elseif ($success_message): ?>
            <div class="success-message">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
